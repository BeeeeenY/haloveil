# HaloVeil 1.0.0 · 光幕

Silent offline macOS screen saver / 无声离线 macOS 屏幕保护程序

## Install / 安装

1. Double-click `HaloVeil.saver` and choose **Install for this user**.
   双击 `HaloVeil.saver`，选择 **仅为此用户安装**。
2. Open **System Settings → Screen Saver → Other → HaloVeil**.
   打开 **系统设置 → 屏幕保护程序 → 其他 / Other → HaloVeil** 切换。
3. On versions with grouped settings, use **System Settings → Wallpaper → Screen Saver → Custom → Other → HaloVeil**.
   如果该版本将屏保放在墙纸中，进入 **系统设置 → 墙纸 → 屏幕保护程序 → 自定 / Custom → 其他 / Other → HaloVeil**。
4. Use **Preview** or a screen saver Hot Corner to start it. Reopen System Settings if HaloVeil has not appeared.
   点击 **预览** 或使用屏保触发角启动；暂时看不到时，退出并重新打开系统设置。

Installing alone may not switch the active saver. Select **HaloVeil under Other**.
安装文件不等于已切换屏保，安装后请务必在 **Other** 中选中 HaloVeil。

Startup prepares resources before a short fade-in. Telemetry is simulated. The screen saver does not replace the password-entry interface or desktop wallpaper.
启动先预热资源再淡入；数据为演示，尚未连接真实 agent，不替换密码输入界面或桌面壁纸。

The build targets macOS 12+ and is ad-hoc signed, not Apple-notarized.
编译目标为 macOS 12 及以上，使用本地签名，未经 Apple 公证。

`HaloVeil Preview.app` runs the same saver in a window without installing it.
直接打开预览 App 可在窗口中查看，无需安装。

## License / 许可

Modified from **HALOFLUX by Ryder191 (RYDER CODE / Ms MAIKEBAIs CAT)**.
Source / 原作来源：https://github.com/Ryder191/haloflux

**Noncommercial use only. Not MIT. / 仅限非商业使用，不是 MIT 许可。**
Read the included LICENSE and NOTICE. / 请阅读随附的完整许可与署名说明。
