
// Modified from HALOFLUX by Ryder191: silent, offline macOS screen saver.
const settings = window.HALOVEIL_SETTINGS;
const release = window.HALOVEIL_RELEASE;
if (!release || (window.HALOVEIL_NATIVE &&
    (!window.HALOVEIL_NATIVE_RELEASE || release.version !== window.HALOVEIL_NATIVE_RELEASE.version ||
     release.assetDigest !== window.HALOVEIL_NATIVE_RELEASE.assetDigest))) {
  throw new Error('HALOVEIL resource/native version mismatch');
}
const runtime = window.HALOVEILRuntime;
const TAU = Math.PI * 2, rnd = Math.random;
const rr = (a, b) => a + rnd() * (b - a);
const pick = a => a[(rnd() * a.length) | 0];
const gauss = () => (rnd() + rnd() + rnd() - 1.5) / 1.5;
let DPR = Math.min(window.devicePixelRatio || 1, settings.maxPixelRatio);
const FONT = 'ui-monospace,"Cascadia Mono","SF Mono",Consolas,"Liberation Mono",monospace';

function mk(w, h) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.ceil(w * DPR)); c.height = Math.max(1, Math.ceil(h * DPR));
  c.x = c.getContext('2d'); c.x.setTransform(DPR, 0, 0, DPR, 0, 0);
  return c;
}
function fit(c) {
  const r = c.getBoundingClientRect();
  c.width = Math.max(1, Math.round(r.width * DPR)); c.height = Math.max(1, Math.round(r.height * DPR));
  const x = c.getContext('2d'); x.setTransform(DPR, 0, 0, DPR, 0, 0);
  c.w = r.width; c.h = r.height; c.x = x;
  return c;
}

/* =========================================================
   MAIN STAGE
   ========================================================= */
// Every frame covers this canvas with an opaque background. Only intermediate
// trail/glow canvases need transparency.
const stage = document.getElementById('stage'); let S = stage.getContext('2d', {alpha:false}); const S_MAIN = S;
let W, H, cx, cy, R, RO, RMAX, thV, thS;
let webBase, webLayers = [], layerEnv = [0, 0, 0], trailC, glowC, laneC;
let curves = [], runners = [], comets = [], cards = [], wedges = [], pulses = [];
let webRot = 0, ringRot = 0, ringVel = 0, OSTEP = 0.0038;
const GS = 3; // glow buffer downscale
const FS = 0.5; let farC; // far-layer buffer (depth of field)
const HAS_FILTER = 'filter' in S;
const easeIO = t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
const easeO = t => 1 - Math.pow(1 - t, 3);

// User-confirmed HALOFLUX preset A. Keep the complete scene aligned with
// tests/fixtures/original-config.json; quality profiles do not select a new scene.
const ORIGINAL_CONFIG = {
  "tempo": 1,
  "camera": 1,
  "camZoom": 1,
  "glow": 1,
  "scan": 1,
  "ringSpeed": 1,
  "ringPause": 1,
  "ringWidth": 1,
  "rimBright": 1,
  "rimWidth": 1,
  "dataFlicker": 1,
  "webBright": 1.25,
  "webPulseBase": 0.3,
  "webPulseAmp": 0.4,
  "webSpin": 1,
  "runnerCount": 45,
  "runnerBright": 1,
  "runnerWidth": 1,
  "runnerSpeed": 1,
  "runnerVariety": 0,
  "cometPerBeat": 2.5,
  "cometBurst": 5,
  "cometTrickle": 1.6,
  "cometLines": 1,
  "cometWidth": 1,
  "cometBright": 1,
  "cometGlow": 0.85,
  "cometSpeed": 1,
  "cometFollow": 1,
  "beamBright": 1,
  "beamBounce": 1,
  "beamLen": 1,
  "beamWidth": 1,
  "beamGlow": 1,
  "dashBright": 1,
  "hazeCount": 8,
  "hazeBright": 1,
  "flyerCount": 1,
  "flyerBright": 1,
  "flyerWidth": 1,
  "flyerSpeed": 1,
  "burstRate": 1,
  "burstSize": 1,
  "burstBright": 1,
  "flareRate": 1,
  "flareBright": 1,
  "rimDensity": 1,
  "depthBlur": 1.4,
  "depthDim": 0.9,
  "webBlur": 0.7,
  "parallax": 0.6,
  "bokeh": 16,
  "bokehBright": 1,
  "atmos": 1,
  "ringShadow": 1,
  "vignette": 0.7
};
const C = {
  ...ORIGINAL_CONFIG,
  ...(Number.isFinite(settings.tempo) ? {tempo:settings.tempo} : {}),
  ...(Number.isFinite(settings.ringSpeed) ? {ringSpeed:settings.ringSpeed} : {}),
  ...(Number.isFinite(settings.ringPause) ? {ringPause:settings.ringPause} : {}),
  ...(Number.isFinite(settings.cameraIntensity) ? {camZoom:settings.cameraIntensity} : {}),
};
const zf = z => 1 + (z - 1) * C.camZoom;

const TOK = ['load_collection()', 'extract_eq', '∂u/∂t', 'rho', 'grad(p)', 'dt=1e-3', 'assert', 'residual', 'solve()',
  'mesh', 'bc.apply', 'flux', 'CFL', '0.0041', 'ok', 'PASS', 'ref#12', 'scene_07', 'u_star', 'div(u)', 'proj', 'advect',
  'step++', 'tol', '1.2e-6', 'kernel', 'paper[37]', 'eq.(4)', 'fig.3', 'table2', 'nu=0.01', 'v_x', 'omega', 'bounce',
  'f_eq', 'stream', 'collide', 'Re=100', 'check', '>>>', 'match', 'diff', 'L2', 'grid64', 'cfg', 'seed=7'];

/* ---------- rhythm: an uneven beat clock drives everything ---------- */
const PATTERN = [0.5, 0.25, 0.25, 0.5, 0.5, 0.75, 0.25, 0.25, 0.25, 1.0];
let beatT = 0.4, beatI = 0, sinceBeat = 9, beatN = 0, env = 0;
function updateBeat(dt) {
  beatT -= dt; sinceBeat += dt;
  if (beatT <= 0) { beatT += PATTERN[beatI++ % PATTERN.length] * 0.92 / C.tempo; sinceBeat = 0; beatN++; onBeat(); }
  env = Math.exp(-sinceBeat * 4.5);
}
function onBeat() {
  // ring: kick every other beat → stepped, fast rotation
  if (rot.t >= rot.dur && rot.hold <= 0) ringMove();
  // comets come in bursts
  const n = Math.round((beatN % 4 === 0 ? C.cometBurst : C.cometPerBeat) * rr(0.6, 1.4));
  for (let i = 0; i < n; i++) runtime.after(spawnComet, i * rr(30, 90));
  // web layers shimmer
  layerEnv[(rnd() * 3) | 0] = 1;
  if (beatN % 4 === 0) layerEnv = layerEnv.map(() => rr(0.6, 1));
  // outer: travelling wave + random wedge hits
  const dir = rnd() < 0.5 ? 1 : -1, big = beatN % 8 === 0;
  pulses.push({ c: dir > 0 ? -thS - 0.15 : thS + 0.15, v: dir * rr(0.7, 1.6) * (big ? 0.7 : 1), w: big ? rr(0.25, 0.4) : rr(0.05, 0.16), amp: big ? 1 : rr(0.45, 0.9), life: rr(1.2, 2.0), L: 0 });
  pulses.forEach(p => p.L || (p.L = p.life));
  onBeatOuter();
  // ring cards
  for (let i = 0; i < Math.round(6 * C.dataFlicker); i++) pick(slots).dirty = true;
  for (let i = 0; i < Math.round(2 * C.dataFlicker); i++) pick(slots).flash = rr(0.35, 0.7);
}

/* ---------- camera: automatic push-in / pull-out shots ---------- */
const cam = { x: 0, y: 0, z: 1 };
let shots = [], shotI = 0, shotT = 0, camPhase = 'hold', camFrom = null;
function buildShots() {
  const P = (a, r) => ({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r });
  const mid = (R + RO) / 2;
  shots = [
    { x: W / 2, y: H / 2, z: 1, hold: 4.5 },
    { ...P(-thS * 0.45, mid), z: 2.3, hold: 3.4 },
    { ...P(0.04, RO + (RMAX - RO) * 0.3), z: 1.6, hold: 3.2 },
    { x: W / 2, y: H / 2, z: 1, hold: 3.0 },
    { ...P(0.22, R * 0.8), z: 1.9, hold: 3.4 },
    { ...P(thS * 0.5, mid + 10), z: 2.8, hold: 3.0 },
    { ...P(-0.12, RO + 40), z: 1.35, hold: 3.2 },
  ];
  shotI = 0; shotT = 0; camPhase = 'hold';
  Object.assign(cam, shots[0]);
}
function clampCam() {
  const hw = W / (2 * cam.z), hh = H / (2 * cam.z);
  cam.x = Math.max(hw, Math.min(W - hw, cam.x));
  cam.y = Math.max(hh, Math.min(H - hh, cam.y));
}
function updateCam(dt) {
  if (!C.camera) { cam.x = W / 2; cam.y = H / 2; cam.z = 1; return; }
  shotT += dt;
  const cur = shots[shotI], nxt = shots[(shotI + 1) % shots.length];
  if (camPhase === 'hold') {
    const k = shotT / cur.hold;
    cam.x = cur.x; cam.y = cur.y + (cur.z > 1 ? Math.sin(k * Math.PI) * 6 : 0);
    cam.z = zf(cur.z) * (1 + 0.05 * k * C.camZoom);            // slow creep while holding
    if (shotT >= cur.hold) { camPhase = 'move'; shotT = 0; camFrom = { ...cam }; }
  } else {
    const dur = 2.2, e = easeIO(Math.min(1, shotT / dur));
    const lz = Math.log(camFrom.z) + (Math.log(zf(nxt.z)) - Math.log(camFrom.z)) * e;
    let z = Math.exp(lz);
    if (camFrom.z > 1.2 && zf(nxt.z) > 1.2) z *= 1 - 0.4 * Math.sin(Math.PI * e); // pull out between two close-ups
    cam.z = Math.max(1, z);
    cam.x = camFrom.x + (nxt.x - camFrom.x) * e;
    cam.y = camFrom.y + (nxt.y - camFrom.y) * e;
    if (shotT >= dur) { shotI = (shotI + 1) % shots.length; camPhase = 'hold'; shotT = 0; }
  }
  clampCam();
}
function camT(ctx, d) { ctx.setTransform(d * cam.z, 0, 0, d * cam.z, d * (W / 2 - cam.x * cam.z), d * (H / 2 - cam.y * cam.z)); }
function camTk(ctx, d, k) {
  const z = 1 + (cam.z - 1) * k, x = W / 2 + (cam.x - W / 2) * k, y = H / 2 + (cam.y - H / 2) * k;
  ctx.setTransform(d * z, 0, 0, d * z, d * (W / 2 - x * z), d * (H / 2 - y * z));
}
const toScreen = (x, y) => ({ x: (x - cam.x) * cam.z + W / 2, y: (y - cam.y) * cam.z + H / 2 });

/* ---------- setup ---------- */
function mkd(w, h, d) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.ceil(w * d)); c.height = Math.max(1, Math.ceil(h * d));
  c.x = c.getContext('2d'); c.x.setTransform(d, 0, 0, d, 0, 0); return c;
}
function resizeStage() {
  const r = stage.getBoundingClientRect();
  W = r.width; H = r.height;
  stage.width = W * DPR; stage.height = H * DPR;
  cx = W * 0.07; cy = H * 0.5;
  R = Math.max(H * 0.78, W * 0.30);
  RO = R + Math.max(90, Math.min(240, H * 0.3, W * 0.13)) * C.ringWidth;
  RMAX = Math.hypot(W - cx, H / 2) + 60;
  thV = Math.asin(Math.min(1, (H / 2 + 60) / R));
  thS = Math.asin(Math.min(1, (H / 2 + 40) / RO));
  buildWeb(); buildLanes(); buildCards(); buildOuter();
  trailC = mkd(2 * R + 4, 2 * R + 4, Math.min(DPR, 1.5));
  farC = document.createElement('canvas'); farC.width = Math.ceil(W * FS); farC.height = Math.ceil(H * FS); farC.x = farC.getContext('2d');
  glowC = document.createElement('canvas');
  glowC.width = Math.ceil(W / GS); glowC.height = Math.ceil(H / GS); glowC.x = glowC.getContext('2d');
  runners = []; for (let i = 0; i < C.runnerCount; i++) runners.push(newRunner(true));
  comets = []; pulses = [];
  buildShots();
  // Fill the ring atlas once, before starting frames. Rotating/zooming never
  // has to allocate a batch of newly visible tile canvases.
  slots.forEach(renderSlot);
}

/* ---------- inner web ---------- */
function buildWeb() {
  const size = 2 * R + 4, d = Math.min(DPR, 1.5);
  webBase = mkd(size, size, d);
  webLayers = [0, 1, 2].map(() => mkd(size, size, d));
  const all = [webBase, ...webLayers];
  all.forEach(c => c.x.translate(R + 2, R + 2));
  const b = webBase.x;
  b.beginPath(); b.arc(0, 0, R, 0, TAU);
  const g = b.createRadialGradient(0, 0, R * 0.2, 0, 0, R);
  g.addColorStop(0, '#111215'); g.addColorStop(1, '#0c0d0f');
  b.fillStyle = g; b.fill();
  all.forEach(c => { c.x.save(); c.x.beginPath(); c.x.arc(0, 0, R, 0, TAU); c.x.clip(); });
  curves = [];
  const N = Math.min(2600, Math.round(1000 + (W * H) / 800));
  for (let i = 0; i < N; i++) {
    const a1 = rnd() * TAU, a2 = a1 + rr(0.6, Math.PI * 1.4);
    const p0 = { x: Math.cos(a1) * R, y: Math.sin(a1) * R };
    const p1 = { x: Math.cos(a2) * R, y: Math.sin(a2) * R };
    const cr = Math.sqrt(rnd()) * R * 0.9, ca = rnd() * TAU;
    const c = { x: Math.cos(ca) * cr, y: Math.sin(ca) * cr };
    curves.push({ p0, c, p1 });
    const layer = rnd() < 0.7 ? -1 : (rnd() * 3) | 0;
    const x = layer < 0 ? b : webLayers[layer].x;
    const al = Math.min(1, (layer < 0 ? 0.03 + Math.pow(rnd(), 3) * 0.28 : 0.08 + Math.pow(rnd(), 2) * 0.35) * C.webBright);
    const k = rnd();
    x.strokeStyle = k < 0.05 ? `rgba(240,166,198,${al})` : k < 0.1 ? `rgba(180,170,235,${al})` : `rgba(228,231,238,${al})`;
    x.lineWidth = rr(0.4, 1.1);
    x.beginPath(); x.moveTo(p0.x, p0.y); x.quadraticCurveTo(c.x, c.y, p1.x, p1.y); x.stroke();
  }
  // node markers
  b.font = `6px ${FONT}`; b.textBaseline = 'middle';
  for (let i = 0; i < 70; i++) {
    const rr_ = Math.sqrt(rnd()) * R * 0.92, a = rnd() * TAU;
    const px = Math.cos(a) * rr_, py = Math.sin(a) * rr_, s = rr(2, 4.5);
    b.strokeStyle = `rgba(235,238,244,${rr(0.35, 0.8)})`; b.lineWidth = 0.8;
    b.beginPath(); b.arc(px, py, s, 0, TAU); b.stroke();
    if (rnd() < 0.4) { b.beginPath(); b.arc(px + s * 2.2, py, s * 0.8, 0, TAU); b.stroke(); }
    if (rnd() < 0.35) { b.fillStyle = 'rgba(200,204,212,.5)'; b.fillText('n' + ((rnd() * 99) | 0), px + 7, py); }
  }
  // dotted chains of small rings (as in the original)
  for (let k = 0; k < 3; k++) {
    const rad = R * rr(0.45, 0.85), a0 = rr(0, TAU), cnt = 22 + (rnd() * 14 | 0);
    b.strokeStyle = 'rgba(235,238,244,.55)'; b.lineWidth = 0.8;
    for (let i = 0; i < cnt; i++) { const a = a0 + i * 0.022; b.beginPath(); b.arc(Math.cos(a) * rad, Math.sin(a) * rad, 2.2, 0, TAU); b.stroke(); }
  }
  all.forEach(c => c.x.restore());
  if (HAS_FILTER && C.webBlur > 0) {
    all.forEach((c, i) => {
      const orig = document.createElement('canvas'); orig.width = c.width; orig.height = c.height; orig.getContext('2d').drawImage(c, 0, 0);
      const x = c.x; x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, c.width, c.height);
      x.filter = `blur(${(i ? 0.5 : 1) * C.webBlur * d}px)`; x.drawImage(orig, 0, 0); x.filter = 'none';
      x.globalAlpha = Math.max(0.15, 1 - C.webBlur * 0.3); x.drawImage(orig, 0, 0); x.restore();
    });
  }
}
const qpt = (cv, t) => {
  const u = 1 - t;
  return { x: u * u * cv.p0.x + 2 * u * t * cv.c.x + t * t * cv.p1.x, y: u * u * cv.p0.y + 2 * u * t * cv.c.y + t * t * cv.p1.y };
};
function newRunner(init) {
  const cv = pick(curves), t = init ? rnd() : 0, p = qpt(cv, t);
  // mixed speed personalities so lone lines never move in lockstep
  const k = rnd(); let mode, sp;
  if (rnd() > C.runnerVariety) { mode = 1; sp = rr(0.12, 0.38); }   // uniform (version A style)
  else if (k < 0.3) { mode = 0; sp = rr(0.15, 0.28); }        // steady, ignores the beat
  else if (k < 0.65) { mode = 1; sp = rr(0.1, 0.3); }    // surges on the beat
  else if (k < 0.8) { mode = 0; sp = rr(0.04, 0.08); }   // slow drift
  else if (k < 0.92) { mode = 0; sp = rr(0.5, 0.85); }   // fast streak
  else { mode = 2; sp = rr(0.06, 0.12); }                 // accelerates along its path
  return { cv, t, sp, mode, px: p.x, py: p.y, b: rnd() < 0.1 };
}

/* ---------- comets: short bright bundles sweeping with ease-in-out ---------- */
function spawnComet() {
  const lines = [], n = Math.max(2, Math.round((8 + (rnd() * 12 | 0)) * C.cometLines));
  if (rnd() < 0.6) {
    // concentric arc bundle hugging the ring
    const rad = R * rr(0.55, 0.9), a0 = rr(-thV, thV) * 0.85, span = rr(0.35, 0.9) * (rnd() < 0.5 ? -1 : 1), gap = rr(2.6, 4.4) * C.cometWidth;
    for (let k = 0; k < n; k++) lines.push({ arc: true, r: rad - k * gap + gauss() * 0.6, a0: a0 + gauss() * 0.01, span });
  } else {
    // converging bundle: inner point → ring edge
    const ang = rr(-thV, thV) * 0.8, oa = ang + rr(-1.3, 1.3), orad = R * rr(0.25, 0.75);
    const o = { x: Math.cos(oa) * orad, y: Math.sin(oa) * orad };
    const spread = rr(0.08, 0.25) * C.cometWidth, bend = rr(0.2, 0.5) * (rnd() < 0.5 ? -1 : 1);
    for (let i = 0; i < n; i++) {
      const ta = ang + (i / n - 0.5) * spread;
      const p1 = { x: Math.cos(ta) * (R - 2), y: Math.sin(ta) * (R - 2) };
      const p0 = { x: o.x + gauss() * 10, y: o.y + gauss() * 10 };
      const mx = (p0.x + p1.x) / 2, my = (p0.y + p1.y) / 2, dx = p1.x - p0.x, dy = p1.y - p0.y;
      lines.push({ p0, c: { x: mx - dy * bend + gauss() * 8, y: my + dx * bend + gauss() * 8 }, p1 });
    }
  }
  comets.push({ lines, life: 0, hit: false, rot0: ringRot, dur: rr(0.4, 0.85) / C.cometSpeed, win: rr(0.22, 0.4), glow: rnd() < 0.4, tint: rnd() < 0.15 });
}
const cpt = (l, t) => { if (!l.arc) return qpt(l, t); const r = l.r + (R - 2 - l.r) * t * t, a = l.a0 + l.span * t; return { x: Math.cos(a) * r, y: Math.sin(a) * r }; };
function strokeComet(ctx, c, t0, t1) {
  ctx.beginPath();
  for (const l of c.lines) {
    const p0 = cpt(l, t0), p1 = cpt(l, t1), span = t1-t0;
    ctx.moveTo(p0.x, p0.y);
    if (!l.arc) {
      // Exact restricted quadratic, replacing 18 sampled line segments.
      const dx = (1-t0)*(l.c.x-l.p0.x)+t0*(l.p1.x-l.c.x);
      const dy = (1-t0)*(l.c.y-l.p0.y)+t0*(l.p1.y-l.c.y);
      ctx.quadraticCurveTo(p0.x+span*dx, p0.y+span*dy, p1.x, p1.y);
    } else {
      // Two short Hermite cubics retain the expanding spiral to subpixel
      // accuracy, without issuing hundreds of line commands per comet.
      const point = t => {
        const k=R-2-l.r, r=l.r+k*t*t, a=l.a0+l.span*t, ca=Math.cos(a), sa=Math.sin(a);
        return {x:r*ca,y:r*sa,dx:2*k*t*ca-r*l.span*sa,dy:2*k*t*sa+r*l.span*ca};
      };
      let a=point(t0);
      for(let segment=1;segment<=2;segment++) {
        const b=point(t0+span*segment/2), k=span/6;
        ctx.bezierCurveTo(a.x+k*a.dx,a.y+k*a.dy,b.x-k*b.dx,b.y-k*b.dy,b.x,b.y);
        a=b;
      }
    }
  }
  ctx.stroke();
}

/* ---------- outer: stacked, constantly changing layers ----------
   L0 haze bands (translucent wide wedges, additive, short lifecycles)
   L1 far strands (thin, dim, slower rotation → parallax)
   L2 main strands (dense, ring-attached, staircase tips + flowing dashes)
   L3 root flares (bright white blocks at the ring edge, glow)          */
let GR = {}, strandLayers = [], hazes = [], flares = [];
const HAZE_COL = ['196,180,252', '242,242,252', '190,222,222'];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const normA = a => ((a + Math.PI) % TAU + TAU) % TAU - Math.PI;
function makeProfile(n) {
  const prof = []; let v = rr(0.45, 1), run = 0;
  for (let k = 0; k < n; k++) {
    if (run-- <= 0) { v = clamp(v + gauss() * 0.4, 0.22, 1); run = 2 + (rnd() * 5 | 0); }
    prof.push(clamp(v + gauss() * 0.07, 0.18, 1));
  }
  return prof;
}
function makeStrandLayer(stepDeg, rotK, lumK, lw, lenK, solidK, cover, nMin, nMax, brightP, dyn = 'soft') {
  const step = stepDeg * Math.PI / 180, nb = Math.floor(TAU / step), ws = [];
  const count = Math.round(nb * cover / ((nMin + nMax) / 2));
  for (let j = 0; j < count; j++) {
    const n = nMin + (rnd() * (nMax - nMin) | 0), bright = rnd() < brightP;
    ws.push({
      i0: (rnd() * nb) | 0, n, base: rr(0.35, 1), len: rr(0.1, 0.5), kick: 0,
      ph: rnd() * TAU, ph2: rnd() * TAU, f1: rr(0.22, 0.6), f2: rr(0.8, 1.7),
      lum: bright ? rr(0.75, 1) : rr(0.16, 0.55), tint: rnd() < 0.5 ? 1 : 0,
      lwK: rnd() < 0.2 ? rr(1.35, 2.1) : rr(0.6, 1.15), lenS: rr(0.6, 1.25),
      prof: makeProfile(n), pf: Array.from({ length: n }, () => rr(1, 4)), pp: Array.from({ length: n }, () => rnd() * TAU),
      ds: Array.from({ length: n }, () => rnd()), dsp: rr(0.7, 1.8), flow: 0,
      coords: new Float64Array(n * 4),
      geom: Array.from({ length: n }, (_, k) => {
        const edge = Math.sin(Math.PI * (k + 0.5) / n), angle = (k + 0.5) * step;
        return {ca:Math.cos(angle), sa:Math.sin(angle),
          lengthFactor:0.5 + 0.5 * Math.sqrt(edge), bucket:edge < 0.38 ? 0 : edge < 0.72 ? 1 : 2};
      })
    });
  }
  return { step, rotK, lumK, lw, lenK, solidK, wedges: ws, off: rnd() * TAU, dyn };
}
function buildOuter() {
  strandLayers = [
    //               step  rotK  lumK  lw    lenK  solidK cover nMin nMax brightP
    makeStrandLayer(0.22, 0.45, 0.30, 0.55, 1.15, 0.9,  1.1,  20,  90, 0.2),   // far: faint, thin, slow
    makeStrandLayer(0.16, 0.75, 0.58, 0.8,  1.05, 0.7,  0.9,  14,  70, 0.28),  // mid
    makeStrandLayer(0.12, 1.0,  1.0,  1.0,  1.0,  0.5,  0.75, 12,  60, 0.32),  // main (dashes + tips)
    makeStrandLayer(0.45, 1.0,  0.5,  1.8,  0.8,  0.6,  0.35, 4,   16, 0.3),   // near: few thick strokes
    makeStrandLayer(0.12, 1.0,  0.85, 1.0,  1.0,  0.5,  0.55, 14,  70, 0.32, 'bounce'),  // v4 wave / rebound layer
  ];
  wedges = strandLayers[2].wedges.concat(strandLayers[4].wedges);
  hazes = []; flares = [];
  GR = {};
  const mkG = (stops, r1) => { const g = S.createRadialGradient(cx, cy, RO, cx, cy, r1); stops.forEach(s => g.addColorStop(s[0], s[1])); return g; };
  GR.s0 = mkG([[0, 'rgba(248,248,255,1)'], [0.35, 'rgba(228,226,242,.8)'], [1, 'rgba(190,190,214,.3)']], RMAX * 0.95);
  GR.s2 = mkG([[0, 'rgba(225,245,242,1)'], [0.3, 'rgba(176,214,210,.8)'], [1, 'rgba(140,180,186,.3)']], RMAX * 0.95);
  GR.s1 = mkG([[0, 'rgba(240,236,255,1)'], [0.3, 'rgba(196,182,244,.82)'], [1, 'rgba(160,140,228,.3)']], RMAX * 0.95);
  // haze tints: lavender / pale white / grey-teal
  GR.h0 = mkG([[0, 'rgba(205,190,255,.95)'], [0.25, 'rgba(180,165,240,.7)'], [0.7, 'rgba(150,135,215,.25)'], [1, 'rgba(120,110,190,0)']], RMAX);
  GR.h1 = mkG([[0, 'rgba(250,250,255,1)'], [0.2, 'rgba(225,225,240,.65)'], [0.65, 'rgba(200,200,225,.2)'], [1, 'rgba(180,180,210,0)']], RMAX);
  GR.h2 = mkG([[0, 'rgba(200,230,228,.9)'], [0.25, 'rgba(170,205,210,.6)'], [0.7, 'rgba(140,170,185,.2)'], [1, 'rgba(120,150,170,0)']], RMAX);
  for (let i = 0; i < 14; i++) spawnHaze(true);
  initFlyers();
}
function spawnHaze(init) {
  const k = rnd();
  hazes.push({
    a: rr(-thS, thS) - ringRot, w: rnd() < 0.7 ? rr(0.015, 0.07) : rr(0.08, 0.18),
    len: rr(0.35, 1), cur: init ? rr(0.2, 0.8) : 0, age: init ? rr(0, 0.5) : 0,
    life: rr(0.35, 1.6), alpha: rr(0.12, 0.42), tint: k < 0.55 ? 0 : k < 0.85 ? 1 : 2, drift: rr(-0.04, 0.04)
  });
}
function spawnFlare(a) {
  flares.push({ a: a == null ? rr(-thS, thS) * 0.95 - ringRot : a, w: rr(0.006, 0.04), len: rr(18, 110), age: 0, life: rr(0.2, 0.55), alpha: rr(0.6, 1) });
}
function buildLanes() {
  laneC = mkd(W, H, DPR);
  const x = laneC.x;
  for (let i = 0; i < 700; i++) {
    const a = rr(-thS, thS);
    x.strokeStyle = `rgba(210,205,235,${rr(0.01, 0.035)})`; x.lineWidth = rr(0.5, 1);
    const r0 = RO + 4, r1 = rr(RO + 60, RMAX * 0.8);
    x.beginPath(); x.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); x.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); x.stroke();
  }
}
function updateOuter(dt) {
  for (let i = pulses.length - 1; i >= 0; i--) { const p = pulses[i]; p.c += p.v * dt; p.life -= dt; if (p.life <= 0) pulses.splice(i, 1); }
  for (const Lr of strandLayers) {
    const rot = ringRot * Lr.rotK + Lr.off;
    for (const w of Lr.wedges) {
      const am = normA((w.i0 + w.n / 2) * Lr.step + rot);
      w.vis = Math.abs(am) < thS + 0.2;
      w.flow += dt * w.dsp * (0.45 + 2.2 * env);
      if (!w.vis) { w.len *= 0.98; continue; }
      let p = 0;
      for (const pl of pulses) { const f = Math.min(1, pl.life / 0.5) * Math.min(1, (pl.L - pl.life) / 0.15 + 0.3); p += pl.amp * f * Math.exp(-(((am - pl.c) / pl.w) ** 2)); }
      if (Lr.dyn === 'bounce') {
        const idle = w.base * (0.36 + 0.14 * Math.sin(T * 0.9 + w.ph));
        const tgt = Math.min(1, idle + p * 0.75 + w.kick * 0.6);
        w.kick *= Math.exp(-dt * 2.4);
        w.len += (tgt - w.len) * Math.min(1, (tgt > w.len ? 15 : 2.2) * dt);   // snap out on the wave, ease back
      } else {
        const n1 = 0.5 + 0.5 * Math.sin(T * w.f1 + w.ph), n2 = 0.5 + 0.5 * Math.sin(T * w.f2 + w.ph2);
        const idle = w.base * (0.4 + 0.34 * n1 + 0.14 * n2);
        const tgt = Math.min(1.05, (idle + p * 0.7 + w.kick * 0.55) * w.lenS);
        w.kick *= Math.exp(-dt * 1.8);
        w.len += (tgt - w.len) * Math.min(1, (tgt > w.len ? 5 : 1.3) * dt);
      }
    }
  }
  // haze lifecycle
  for (let i = hazes.length - 1; i >= 0; i--) {
    const h = hazes[i]; h.age += dt;
    h.cur += (h.len - h.cur) * Math.min(1, 9 * dt);
    if (h.age > h.life + 0.6) hazes.splice(i, 1);
  }
  if (hazes.length < C.hazeCount && rnd() < 0.25) spawnHaze(false);
  for (let i = flares.length - 1; i >= 0; i--) { flares[i].age += dt; if (flares[i].age > flares[i].life) flares.splice(i, 1); }
  if (rnd() < 0.06 * C.flareRate) spawnFlare();
  updateFlyers(dt);
}
function onBeatOuter() {
  onBeatFlyers();
  for (let i = 0; i < 2 + (rnd() * 5 | 0); i++) { const w = pick(wedges); w.kick = rr(0.4, 1); if (rnd() < 0.5) w.prof = makeProfile(w.n); }
  for (let i = 0; i < 2; i++) { const w = pick(wedges); w.lum = rnd() < 0.4 ? rr(0.8, 1) : rr(0.25, 0.6); }
  const nh = beatN % 4 === 0 ? 5 + (rnd() * 4 | 0) : 1 + (rnd() * 3 | 0);
  for (let i = 0; i < Math.round(nh * C.hazeCount / 8); i++) spawnHaze(false);
  const nf = Math.round((1 + (rnd() * 4 | 0)) * C.flareRate);
  for (let i = 0; i < nf; i++) spawnFlare(hazes.length && rnd() < 0.6 ? pick(hazes).a : null);
}
function hazeEnv(h) {
  const a = Math.min(1, h.age / 0.12);                       // fast in
  const o = h.age > h.life ? Math.max(0, 1 - (h.age - h.life) / 0.6) : 1; // slower out
  return a * o * (0.85 + 0.15 * Math.sin(h.age * 30));      // slight flicker
}
const EDGE_A = [0.28, 0.62, 1];
function drawStrands(Lr, collect) {
  const span = RMAX - RO - 20, r0 = RO + 3, rot = ringRot * Lr.rotK + Lr.off;
  S.lineCap = 'butt';
  for (const w of Lr.wedges) {
    if (!w.vis) continue;
    const L = w.len * span * Lr.lenK * C.beamLen;
    if (L < 3) continue;
    const a0 = normA(w.i0 * Lr.step + rot), a1 = a0 + w.n * Lr.step;
    if (a1 < -thS - 0.03 || a0 > thS + 0.03) continue;
    const alpha = Math.min(1, w.lum * Lr.lumK * (0.3 + 0.7 * Math.min(1, w.len * 1.8)) * C.beamBright * (Lr.dyn === 'bounce' ? C.beamBounce : 1));
    if (alpha < 0.005) continue;
    const lwW = Lr.lw * w.lwK * C.beamWidth;
    const coords = w.coords, ca0 = Math.cos(a0), sa0 = Math.sin(a0);
    for (let k = 0; k < w.n; k++) {
      const geom = w.geom[k], b = geom.bucket;
      const ca = ca0 * geom.ca - sa0 * geom.sa, sa = sa0 * geom.ca + ca0 * geom.sa;
      const pr = w.prof[k];
      const l = L * pr * geom.lengthFactor * (0.92 + 0.08 * Math.sin(T * w.pf[k] + w.pp[k]));
      const solid = l * (Lr.solidK + 0.3 * pr * (1 - Lr.solidK));
      const offset = k * 4;
      coords[offset] = cx + ca * r0; coords[offset+1] = cy + sa * r0;
      coords[offset+2] = cx + ca * (r0 + solid); coords[offset+3] = cy + sa * (r0 + solid);
      if (!collect) continue;
      const tail = l - solid, da = alpha * EDGE_A[b];
      if (tail > 6) for (let d = 0; d < 2; d++) {
        const ph = (w.flow + w.ds[k] + d * 0.5) % 1;
        const s0 = solid + tail * ph, s1 = Math.min(l, s0 + 3 + tail * 0.22 * (1 - ph * 0.5));
        if (s1 > s0) collect.dash.push(ca, sa, s0, s1, da);
      }
      if ((k + (T * 12 | 0)) % 4 === 0) collect.tip.push(ca, sa, l, da);
    }
    S.strokeStyle = GR['s' + w.tint]; S.lineWidth = lwW;
    for (let b = 0; b < 3; b++) {
      S.beginPath();
      for (let k = 0; k < w.n; k++) {
        if (w.geom[k].bucket !== b) continue;
        const offset = k * 4;
        S.moveTo(coords[offset], coords[offset+1]); S.lineTo(coords[offset+2], coords[offset+3]);
      }
      S.globalAlpha = alpha * EDGE_A[b]; S.stroke();
    }
    if (w.lum > 0.85 && C.beamGlow > 0) { S.globalAlpha = Math.min(1, alpha * 0.06 * C.beamGlow); S.lineWidth = lwW * 2.5; S.stroke(); }
  }
}
const hash = x => { const s = Math.sin(x * 12.9898) * 43758.5453; return s - Math.floor(s); };
function radialLines(a0, a1, st, r0, L, seed, lo) {
  S.beginPath();
  let k = 0;
  for (let a = a0; a < a1; a += st, k++) {
    const l = L * (lo + (1 - lo) * hash(k + seed)), ca = Math.cos(a), sa = Math.sin(a);
    S.moveTo(cx + ca * r0, cy + sa * r0); S.lineTo(cx + ca * (r0 + l), cy + sa * (r0 + l));
  }
}
/* ---- fly-out streaks: shoot outward and never retract, interleaved with the beams ----
   singles: sparse, dimmer, respawn forever
   bursts : packets of parallel streaks launched together on the beat, brighter, die at the edge */
let flyers = [], flyBands = [];
function newFlyBand() { return { a: rr(-thS, thS), w: rr(0.01, 0.05), life: rr(2, 6) }; }
function newFlyer(init) {
  let a;
  if (rnd() < 0.5) { const b = pick(flyBands); a = b.a + gauss() * b.w; } else a = rr(-thS, thS);
  return {
    a: a - ringRot, len: 20 + Math.pow(rnd(), 2) * 320, r: init ? rr(RO, RMAX) : RO + rr(0, 25),
    sp: rr(260, 900), lw: rnd() < 0.08 ? rr(1.2, 1.7) : rr(0.5, 1), lv: rnd() < 0.12 ? 1 : 0, tint: rnd() < 0.22 ? 1 : 0, burst: false
  };
}
function spawnFlyBurst() {
  const a = rr(-thS, thS) * 0.95, n = Math.max(1, Math.round((14 + (rnd() * 30 | 0)) * C.burstSize)), spread = rr(0.01, 0.045);
  const sp = rr(450, 1150), len = rr(70, 320), r0 = RO + rr(0, 8), tint = rnd() < 0.3 ? 1 : 0, lv = rnd() < 0.45 ? 2 : 1;
  for (let i = 0; i < n; i++) {
    flyers.push({
      a: a + (i / n - 0.5) * spread + gauss() * 0.0015 - ringRot, len: len * rr(0.7, 1.15), r: r0 - rr(0, len * 0.35),
      sp: sp * rr(0.92, 1.08), lw: rnd() < 0.2 ? 1.3 : rr(0.6, 1), lv, tint, burst: true
    });
  }
}
function initFlyers() {
  flyBands = Array.from({ length: 7 }, newFlyBand);
  flyers = Array.from({ length: Math.round(Math.min(750, 320 + W * 0.25) * C.flyerCount) }, () => newFlyer(true));
}
function updateFlyers(dt) {
  for (const b of flyBands) { b.life -= dt; if (b.life <= 0) Object.assign(b, newFlyBand()); }
  const k = (0.7 + 0.9 * env) * C.flyerSpeed;
  let write = 0;
  for (let i = 0; i < flyers.length; i++) {
    let f = flyers[i];
    f.r += f.sp * dt * k;
    if (f.r - f.len > RMAX) { if (f.burst) continue; else f = newFlyer(false); }
    flyers[write++] = f;
  }
  // Bursts can retire hundreds of entries together. Compact once rather than
  // splice repeatedly and shift the remaining particle array for every entry.
  flyers.length = write;
}
function onBeatFlyers() {
  const n = Math.round((beatN % 4 === 0 ? 3 + (rnd() * 2 | 0) : 1 + (rnd() * 2 | 0)) * C.burstRate);
  for (let i = 0; i < n; i++) runtime.after(spawnFlyBurst, i * rr(20, 120));
}
const FLY_A = [0.16, 0.36, 0.7];
const flyerBuckets = Object.create(null);
function drawFlyers(bursts) {
  const buckets = flyerBuckets;
  for (const key in buckets) buckets[key].length = 0;
  for (const f of flyers) {
    if (f.burst !== bursts) continue;
    const a = normA(f.a + ringRot);
    if (a < -thS - 0.05 || a > thS + 0.05) continue;
    const key = f.tint * 10 + f.lv + (f.lw > 1.15 ? 100 : 0) + (f.burst ? 1000 : 0);
    (buckets[key] || (buckets[key] = [])).push(f, a);
  }
  for (const key in buckets) {
    const arr = buckets[key]; if (!arr.length) continue;
    const f0 = arr[0];
    S.strokeStyle = f0.tint ? GR.s1 : GR.s0; S.globalAlpha = Math.min(1, FLY_A[f0.lv] * (f0.burst ? C.burstBright : C.flyerBright)); S.lineWidth = ((key % 1000) >= 100 ? 1.5 : 0.8) * C.flyerWidth;
    S.beginPath();
    for (let i = 0; i < arr.length; i += 2) {
      const f = arr[i], a = arr[i + 1], r0 = Math.max(RO + 3, f.r - f.len), r1 = f.r;
      if (r1 <= r0) continue;
      const ca = Math.cos(a), sa = Math.sin(a);
      S.moveTo(cx + ca * r0, cy + sa * r0); S.lineTo(cx + ca * r1, cy + sa * r1);
    }
    S.stroke();
  }
  S.globalAlpha = 1;
}
function drawOuterFar() {
  const span = RMAX - RO - 20, r0 = RO + 3;
  // haze bundles 鈥?very dense, faint lines that merge into soft bands
  for (const h of hazes) {
    const e = hazeEnv(h); if (e <= 0.01) continue;
    if (h.seed === undefined) h.seed = rnd() * 1000;
    const L = h.cur * span;
    radialLines(h.a + ringRot - h.w / 2, h.a + ringRot + h.w / 2, OSTEP * 0.55, r0, L, h.seed, 0.45);
    S.strokeStyle = GR['s' + (h.tint === 1 ? 0 : h.tint === 2 ? 2 : 1)];
    S.globalAlpha = Math.min(1, h.alpha * e * 0.05 * C.hazeBright); S.lineWidth = 2.2; S.stroke();
    S.globalAlpha = Math.min(1, h.alpha * e * 0.6 * C.hazeBright); S.lineWidth = 0.55; S.stroke();
  }
  drawStrands(strandLayers[0], null);   // far strands
  drawStrands(strandLayers[1], null);   // mid strands
  drawFlyers(false);                    // single fly-outs live in the background
  S.globalAlpha = 1;
}
const outerCollect = {dash:[], tip:[]};
function drawOuterNear() {
  const r0 = RO + 3;
  const col = outerCollect; col.dash.length = 0; col.tip.length = 0;
  drawStrands(strandLayers[2], col);
  drawStrands(strandLayers[4], col);   // wave / rebound layer
  drawStrands(strandLayers[3], null);   // near thick strokes
  S.strokeStyle = '#fff'; S.lineWidth = 1.05;
  for (const lv of [0.35, 0.65, 1]) {
    S.globalAlpha = Math.min(1, lv * C.dashBright); S.beginPath();
    const dp = col.dash;
    for (let i = 0; i < dp.length; i += 5) {
      const a = dp[i + 4]; if (a > lv || a <= lv - 0.35) continue;
      S.moveTo(cx + dp[i] * (r0 + dp[i + 2]), cy + dp[i + 1] * (r0 + dp[i + 2])); S.lineTo(cx + dp[i] * (r0 + dp[i + 3]), cy + dp[i + 1] * (r0 + dp[i + 3]));
    }
    S.stroke();
  }
  S.fillStyle = '#fff';
  for (let i = 0; i < col.tip.length; i += 4) {
    S.globalAlpha = Math.min(1, col.tip[i + 3] * 1.2);
    const r = r0 + col.tip[i + 2];
    S.fillRect(cx + col.tip[i] * r - 0.8, cy + col.tip[i + 1] * r - 0.8, 1.6, 1.6);
  }
  drawFlyers(true);                     // burst packets are in the foreground
  S.strokeStyle = GR.s0;
  for (const f of flares) {
    if (f.seed === undefined) f.seed = rnd() * 1000;
    const t = f.age / f.life, e = (t < 0.15 ? t / 0.15 : Math.pow(1 - (t - 0.15) / 0.85, 2)) * f.alpha;
    const L = f.len * (0.6 + 0.4 * easeO(Math.min(1, t * 3)));
    radialLines(f.a + ringRot - f.w / 2, f.a + ringRot + f.w / 2, OSTEP * 0.45, r0, L, f.seed, 0.4);
    S.globalAlpha = Math.min(1, e * 0.06 * C.flareBright); S.lineWidth = 2.6; S.stroke();
    S.globalAlpha = Math.min(1, e * C.flareBright); S.lineWidth = 0.8; S.stroke();
  }
  S.globalAlpha = 1;
}

/* ---------- foreground bokeh: out-of-focus specks closest to the viewer ---------- */
let bokehs = [], bokehSpr = null;
function mkBokehSprite() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,.9)'); g.addColorStop(0.5, 'rgba(235,232,255,.5)'); g.addColorStop(0.82, 'rgba(220,215,255,.22)');
  g.addColorStop(0.93, 'rgba(225,220,255,.32)'); g.addColorStop(1, 'rgba(220,215,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128); return c;
}
function newBokeh() {
  const big = rnd() < 0.3;
  return { x: rr(-0.1, 1.1) * W, y: rr(-0.1, 1.1) * H, r: big ? rr(24, 64) : rr(5, 22), a: big ? rr(0.025, 0.07) : rr(0.05, 0.16),
    vx: rr(-10, 10), vy: rr(-6, 6), st: rnd() < 0.3 ? rr(2, 5) : 1, ph: rnd() * TAU };
}
function drawBokeh(dt) {
  const n = Math.round(C.bokeh);
  while (bokehs.length < n) bokehs.push(newBokeh());
  if (bokehs.length > n) bokehs.length = n;
  if (!n) return;
  if (!bokehSpr) bokehSpr = mkBokehSprite();
  const k = 1 + 0.6 * C.parallax, z = 1 + (cam.z - 1) * k, ox = (cam.x - W / 2) * k, oy = (cam.y - H / 2) * k;
  S.setTransform(DPR, 0, 0, DPR, 0, 0); S.globalCompositeOperation = 'lighter';
  for (const b of bokehs) {
    b.x += b.vx * dt; b.y += b.vy * dt;
    if (b.x < -0.15 * W) b.x += 1.3 * W; if (b.x > 1.15 * W) b.x -= 1.3 * W;
    if (b.y < -0.15 * H) b.y += 1.3 * H; if (b.y > 1.15 * H) b.y -= 1.3 * H;
    const sx = (b.x - W / 2 - ox) * z + W / 2, sy = (b.y - H / 2 - oy) * z + H / 2, r = b.r * z;
    S.globalAlpha = Math.min(1, b.a * C.bokehBright * (0.75 + 0.25 * Math.sin(T * 0.8 + b.ph)) * (1 + env * 0.3));
    S.drawImage(bokehSpr, sx - r * b.st, sy - r, 2 * r * b.st, 2 * r);
  }
  S.globalAlpha = 1; S.globalCompositeOperation = 'source-over';
}
/* ---------- ring: pre-rendered dot-matrix data blocks on a black band ---------- */
const RING_SC = settings.ringCacheScale || 2.4;
let slots = [];
let slotBuildCount = 0, slotBuildMS = 0;
const easeOX = t => t >= 1 ? 1 : 1 - Math.pow(2, -10 * t);
const rot = { from: 0, to: 0, t: 1, dur: 1, hold: 0, ease: easeIO };
function ringMove() {
  const r = rnd(); let d, dur, ease;
  if (r < 0.22) { d = rr(1.1, 2.1); dur = rr(0.7, 1.05); ease = easeIO; }        // fast spin
  else if (r < 0.64) { d = rr(0.14, 0.48); dur = rr(0.18, 0.38); ease = easeOX; } // snap & stop
  else { d = rr(0.05, 0.18); dur = rr(0.3, 0.6); ease = easeIO; }               // small nudge
  if (rnd() < 0.08) d = -d * 0.5;  d *= C.ringSpeed;
  Object.assign(rot, { from: ringRot, to: ringRot + d, t: 0, dur, ease, hold: rr(0.04, 0.4) * C.ringPause });
}
function flashSlotAt(ang) {
  let best = null, bd = 9;
  for (const s of slots) { const d = Math.abs(normA(s.a + ringRot - ang)); if (d < bd) { bd = d; best = s; } }
  if (best && bd < 0.08) best.flash = Math.max(best.flash, 0.8);
}
function updateRing(dt) {
  if (rot.t < rot.dur) { rot.t += dt; ringRot = rot.from + (rot.to - rot.from) * rot.ease(Math.min(1, rot.t / rot.dur)); }
  else { rot.hold -= dt; ringRot += 0.02 * dt; }
}
function buildCards() {
  slots = [];
  const band = RO - R, mid = R + band * 0.42;
  let a = 0;
  while (a < TAU - 0.03) {
    const hpx = rr(16, 62), da = hpx / mid, gap = rr(3, 9) / mid;
    slots.push({ a: a + da / 2, da, hpx, c: null, flash: 0 });
    a += da + gap;
  }
  Object.assign(rot, { from: 0, to: 0, t: 1, dur: 1, hold: 0 });
}
const TINTS = [[232, 234, 240], [232, 234, 240], [232, 234, 240], [232, 234, 240], [232, 234, 240], [232, 234, 240], [196, 184, 246], [196, 184, 246], [168, 222, 214], [206, 212, 150]];
const HEAD = ['SOLVER/02', 'EXTRACT', 'REF.SCENE 07', 'METHOD M04', 'CHECK', 'RESIDUAL', 'PAPER 37', 'AGENT 09', 'BUFFER A',
  'DIFF FIELD', 'STEP 1284', 'MESH 64x64', 'PROJECT', 'ADVECT', 'BC / WALL', 'LBM D2Q9', 'QUEUE', 'TRACE', 'EQ.(4)', 'FIG.3', 'VALIDATE', 'SCENE 12'];
const KEYS = ['dt', 'CFL', 'nu', 'Re', 'tol', 'iter', 'L2', 'mass', 'div', 'u_max', 'rho', 'err', 'grid', 'seed'];
const CODE_T = ['load()', 'step(u)', 'proj(p)', 'bc.apply', 'solve()', 'grad p', 'div u', 'assert', 'f_eq', 'stream', 'collide', 'ok', 'PASS',
  'ref#12', 'diff', 'L2<tol', 'u*', '->', '==', 'dt/2', 'emit', 'push', 'read', 'fig3', 'eq4'];
const rgba = (t, a) => `rgba(${t[0]},${t[1]},${t[2]},${a})`;
const fmtNum = () => { const k = rnd(); return k < 0.3 ? rr(0, 1).toFixed(3) : k < 0.55 ? (rr(1, 9).toFixed(1) + 'e-' + (2 + (rnd() * 5 | 0))) : k < 0.8 ? String((rnd() * 9999) | 0) : rr(0, 100).toFixed(1); };
function glyphStrips(x, x1, y0, y1, pitch, opt, ctx) {
  const tint = opt.tint;
  for (let lx = x; lx < x1 - 1; lx += pitch) {
    if (opt.colGap && rnd() < 0.18) { lx += pitch * 0.8; continue; }
    const len = (y1 - y0) * (opt.ragged ? rr(0.35, 1) : rr(0.85, 1));
    const start = opt.ragged && rnd() < 0.3 ? y0 + rr(0, (y1 - y0) * 0.3) : y0;
    let y = start;
    const lb = rr(0.55, 1);
    while (y < Math.min(y1, start + len)) {
      const cl = opt.solid ? rr(2, 6) : rr(0.9, 2.2);
      if (rnd() < 0.9) { ctx.fillStyle = rgba(tint, lb * rr(0.6, 1)); ctx.fillRect(lx, y, opt.th, Math.min(cl, y1 - y)); }
      y += cl + (rnd() < 0.12 ? rr(1.5, 3) : rr(0.5, 0.9));
    }
  }
}
// ---- block renderers: (ctx, x0, x1, y0, y1, tint) — x is radial, y is tangential ----
function header(c, x0, x1, y, t) {
  c.font = `700 4.3px ${FONT}`; c.fillStyle = rgba(t, 0.95); c.fillText(pick(HEAD), x0, y);
  c.fillStyle = rgba(t, 0.55); c.fillText(String((rnd() * 99) | 0).padStart(2, '0'), x1 - 6, y);
  c.fillStyle = rgba(t, 0.3); c.fillRect(x0, y + 5.6, x1 - x0, 0.45);
  return y + 7.5;
}
const BLOCKS = {
  code(c, x0, x1, y0, y1, t) {
    let y = header(c, x0, x1, y0, t);
    c.font = `500 3.5px ${FONT}`;
    let n = 1 + (rnd() * 40 | 0);
    while (y < y1 - 3.5) {
      c.fillStyle = rgba(t, 0.3); c.fillText(String(n++).padStart(3, '0'), x0, y);
      let xx = x0 + 9;
      const words = 1 + (rnd() * 4 | 0);
      for (let i = 0; i < words && xx < x1 - 4; i++) {
        const w = pick(CODE_T); c.fillStyle = rgba(t, rnd() < 0.25 ? 1 : rr(0.5, 0.8)); c.fillText(w, xx, y); xx += w.length * 2.15 + 2;
      }
      y += 4.6;
    }
  },
  kv(c, x0, x1, y0, y1, t) {
    let y = y1 - y0 > 18 ? header(c, x0, x1, y0, t) : y0 + 1;
    c.font = `500 3.6px ${FONT}`;
    while (y < y1 - 4) {
      c.fillStyle = rgba(t, 0.5); c.fillText(pick(KEYS), x0, y);
      const v = fmtNum(); c.fillStyle = rgba(t, 0.95); c.textAlign = 'right'; c.fillText(v, x1, y); c.textAlign = 'left';
      const bx = x0 + 14, bw = Math.max(0, x1 - x0 - 14 - v.length * 2.2 - 4);
      c.fillStyle = rgba(t, 0.15); c.fillRect(bx, y + 1.2, bw, 1.2);
      c.fillStyle = rgba(t, 0.7); c.fillRect(bx, y + 1.2, bw * rnd(), 1.2);
      y += 5.2;
    }
  },
  spark(c, x0, x1, y0, y1, t) {
    const y = header(c, x0, x1, y0, t), top = y + 1, bot = y1 - 2, n = 40;
    c.fillStyle = rgba(t, 0.18); c.fillRect(x0, bot, x1 - x0, 0.4); c.fillRect(x0, (top + bot) / 2, x1 - x0, 0.25);
    c.strokeStyle = rgba(t, 0.95); c.lineWidth = 0.55; c.beginPath();
    let v = rnd(), lx = 0, ly = 0;
    for (let i = 0; i <= n; i++) {
      v = clamp(v + gauss() * 0.22, 0, 1);
      lx = x0 + (x1 - x0) * i / n; ly = bot - v * (bot - top);
      i ? c.lineTo(lx, ly) : c.moveTo(lx, ly);
    }
    c.stroke(); c.fillStyle = '#fff'; c.fillRect(lx - 0.9, ly - 0.9, 1.8, 1.8);
  },
  bars(c, x0, x1, y0, y1, t) {
    const y = header(c, x0, x1, y0, t), n = 6 + (rnd() * 10 | 0), bh = (y1 - y - 1) / n;
    c.font = `500 3px ${FONT}`;
    for (let i = 0; i < n; i++) {
      const v = rr(0.1, 1), yy = y + i * bh;
      c.fillStyle = rgba(t, 0.35); c.fillText(String(i).padStart(2, '0'), x0, yy);
      c.fillStyle = rgba(t, v > 0.85 ? 1 : 0.65); c.fillRect(x0 + 7, yy + 0.4, (x1 - x0 - 7) * v, Math.max(0.8, bh - 1.2));
    }
  },
  prog(c, x0, x1, y0, y1, t) {
    let y = y1 - y0 > 18 ? header(c, x0, x1, y0, t) : y0 + 1;
    c.font = `500 3.4px ${FONT}`;
    while (y < y1 - 5) {
      const p = rnd();
      c.fillStyle = rgba(t, 0.55); c.fillText(pick(['read', 'build', 'review', 'qa', 'sync', 'diff']), x0, y);
      c.fillStyle = rgba(t, 0.9); c.textAlign = 'right'; c.fillText((p * 100 | 0) + '%', x1, y); c.textAlign = 'left';
      const bx = x0 + 15, bw = x1 - x0 - 26, segs = 12;
      for (let i = 0; i < segs; i++) { c.fillStyle = rgba(t, i / segs < p ? 0.85 : 0.14); c.fillRect(bx + i * bw / segs, y + 0.6, bw / segs - 0.6, 2); }
      y += 5.4;
    }
  },
  grid(c, x0, x1, y0, y1, t) {
    const y = y1 - y0 > 20 ? header(c, x0, x1, y0, t) : y0 + 1, p = rr(2.4, 3.2);
    for (let yy = y; yy < y1 - p + 0.5; yy += p) for (let xx = x0; xx < x1 - p + 0.5; xx += p) {
      const v = rnd();
      c.fillStyle = v > 0.93 ? 'rgba(240,166,198,.95)' : rgba(t, 0.08 + v * v * 0.8);
      c.fillRect(xx, yy, p - 0.6, p - 0.6);
    }
  },
  gauge(c, x0, x1, y0, y1, t) {
    const r = Math.min((y1 - y0) / 2 - 1.5, 9), gx = x0 + r + 1, gy = (y0 + y1) / 2, v = rnd();
    c.lineWidth = 1.2; c.strokeStyle = rgba(t, 0.15); c.beginPath(); c.arc(gx, gy, r, 0, TAU); c.stroke();
    c.strokeStyle = rgba(t, 0.95); c.beginPath(); c.arc(gx, gy, r, -Math.PI / 2, -Math.PI / 2 + TAU * v); c.stroke();
    c.font = `700 ${Math.max(3.2, r * 0.55)}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillStyle = rgba(t, 1); c.fillText((v * 100 | 0) + '', gx, gy); c.textAlign = 'left'; c.textBaseline = 'top';
    if (x1 - (gx + r) > 20) BLOCKS.kv(c, gx + r + 4, x1, y0, y1, t);
  },
  wave(c, x0, x1, y0, y1, t) {
    const y = header(c, x0, x1, y0, t), mid = (y + y1) / 2, amp = (y1 - y) * 0.38, f1 = rr(0.15, 0.4), f2 = rr(0.5, 1.2), ph = rnd() * 6;
    [[0.95, 1], [0.4, -0.6]].forEach(([a, k]) => {
      c.strokeStyle = rgba(t, a); c.lineWidth = 0.5; c.beginPath();
      for (let xx = x0; xx <= x1; xx += 0.8) { const yy = mid + amp * k * (Math.sin(xx * f1 + ph) * 0.7 + Math.sin(xx * f2) * 0.3); xx === x0 ? c.moveTo(xx, yy) : c.lineTo(xx, yy); }
      c.stroke();
    });
  },
  para(c, x0, x1, y0, y1, t) { glyphStrips(x0, x1, y0, y1, rr(2.6, 3.4), { tint: t, ragged: true, th: 1.3 }, c); },
  cols(c, x0, x1, y0, y1, t) { glyphStrips(x0, x1, y0, y1, rr(3.6, 4.6), { tint: t, colGap: true, th: 1.5 }, c); },
  barcode(c, x0, x1, y0, y1, t) { glyphStrips(x0, x1, y0, y1, rr(3.2, 4.2), { tint: t, solid: true, th: 1.8 }, c); },
  matrix(c, x0, x1, y0, y1, t) {
    const p = rr(2.1, 2.6), dens = rr(0.35, 0.65);
    for (let yy = y0; yy < y1 - 1; yy += p) for (let xx = x0; xx < x1; xx += p)
      if (rnd() < dens) { c.fillStyle = rgba(t, rr(0.5, 1)); c.fillRect(xx, yy, 1.4, 1.4); }
  },
};
const BLOCK_W = [['code', 16], ['kv', 11], ['spark', 9], ['bars', 8], ['prog', 7], ['grid', 7], ['gauge', 3], ['wave', 4],
  ['para', 12], ['cols', 7], ['barcode', 6], ['matrix', 8]];
const NEEDS_H = { code: 18, spark: 18, bars: 20, wave: 18, gauge: 16 };
function pickBlock(h) {
  for (let tries = 0; tries < 8; tries++) {
    let r = rnd() * 100, name = 'para';
    for (const [n, w] of BLOCK_W) { r -= w; if (r <= 0) { name = n; break; } }
    if (!NEEDS_H[name] || h >= NEEDS_H[name]) return name;
  }
  return pick(['para', 'kv', 'matrix', 'barcode']);
}
function renderSlot(s) {
  const band = RO - R, h = s.hpx;
  const started = performance.now();
  const c = s.c || document.createElement('canvas');
  const width = Math.ceil(band * RING_SC), height = Math.ceil((h + 2) * RING_SC);
  if (c.width !== width || c.height !== height) { c.width = width; c.height = height; }
  const x = c.getContext('2d');
  x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, c.width, c.height);
  x.setTransform(RING_SC, 0, 0, RING_SC, 0, 0);
  x.globalAlpha = 1; x.globalCompositeOperation = 'source-over';
  x.lineWidth = 1; x.lineCap = 'butt'; x.lineJoin = 'miter';
  x.font = '10px sans-serif'; x.textAlign = 'start'; x.textBaseline = 'top';
  const RB = rimW(), dz0 = RB + 6, dz1 = band * 0.72, oz0 = band * 0.78, oz1 = band - RB - 5;
  const split = rnd() < 0.45 && dz1 - dz0 > 60;
  const blocks = [];
  if (split) { const m = dz0 + (dz1 - dz0) * rr(0.42, 0.6); blocks.push([dz0, m], [m + rr(4, 8), dz1]); }
  else blocks.push([dz0, dz1 - rr(0, 18)]);
  for (const [b0, b1] of blocks) {
    const tint = pick(TINTS), y0 = 1 + rr(0, 2), y1 = h + 1 - rr(0, 2);
    x.save(); x.beginPath(); x.rect(b0, y0 - 0.5, b1 - b0, y1 - y0 + 1); x.clip();
    BLOCKS[pickBlock(y1 - y0)](x, b0, b1, y0, y1, tint);
    x.restore();
  }
  // outer index column: tiny ids + tick groups
  const pitch = rr(8, 12);
  x.font = `600 3.1px ${FONT}`;
  for (let yy = rr(1, pitch); yy < h - 2; yy += pitch) {
    if (rnd() < 0.15) continue;
    let xx = oz0 + rr(0, 3);
    if (rnd() < 0.45) { x.fillStyle = `rgba(225,228,236,${rr(0.55, 0.95)})`; x.fillText(String((rnd() * 999) | 0).padStart(3, '0'), xx, yy - 1); xx += 9; }
    const n = 1 + (rnd() * 3 | 0);
    for (let i = 0; i < n && xx < oz1; i++) { x.fillStyle = `rgba(225,228,236,${rr(0.5, 0.95)})`; x.fillRect(xx, yy, rr(1.2, 2.4), 1.2); xx += rr(2.4, 3.6); }
  }
  if (rnd() < 0.45) {
    x.fillStyle = 'rgba(220,224,232,.7)';
    for (let xx = dz0; xx < oz1; xx += rr(2.4, 4.5)) if (rnd() < 0.8) x.fillRect(xx, h + 0.4, 1.1, 1.1);
  }
  s.c = c; s.dirty = false;
  slotBuildCount++; slotBuildMS += performance.now() - started;
}
function rimW() { return Math.max(3, (RO - R) * 0.065 * C.rimWidth); }
function drawRing(dt) {
  const band = RO - R;
  S.globalCompositeOperation = 'source-over';
  S.save(); S.translate(cx, cy);
  S.beginPath(); S.arc(0, 0, RO, 0, TAU); S.arc(0, 0, R, 0, TAU, true);
  S.fillStyle = '#040506'; S.fill('evenodd');
  // All tiles already exist. Keep cold-start frames free of random tile rebuilds.
  let regen = warmupDrawing || (nativeDriver && T < 1) ? 0 : 1;
  for (const s of slots) {
    const A = s.a + ringRot;
    if (s.flash > 0) s.flash = Math.max(0, s.flash - dt * 2.2);
    const mid = R + band * 0.42;
    const sp = toScreen(cx + Math.cos(A) * mid, cy + Math.sin(A) * mid);
    if (sp.x < -140 || sp.x > W + 140 || sp.y < -140 || sp.y > H + 140) continue;
    // Upstream beat invalidations bypass the random one-tile refresh budget.
    const refresh = settings.originalCompositing ?
      (s.dirty || (regen > 0 && rnd() < 0.02)) :
      (regen > 0 && (s.dirty || rnd() < 0.02));
    if (!s.c || refresh) { renderSlot(s); regen--; }
    S.save(); S.rotate(A);
    const hh = s.hpx + 2;
    S.drawImage(s.c, R, -hh / 2, band, hh);
    if (s.flash > 0.02) { S.globalCompositeOperation = 'lighter'; S.globalAlpha = s.flash; S.drawImage(s.c, R, -hh / 2, band, hh); S.globalAlpha = 1; S.globalCompositeOperation = 'source-over'; }
    S.restore();
  }
  // rulers & rim bands (all rotate with the ring)
  const tick = (step, fn) => {
    const n0 = Math.floor((-thV - 0.05 - ringRot) / step), n1 = Math.ceil((thV + 0.05 - ringRot) / step);
    for (let n = n0; n <= n1; n++) { const a = n * step + ringRot; fn(Math.cos(a), Math.sin(a), n); }
  };
  const RB = rimW();
  // inner + outer rim bands: dense white hairlines that give the edge its thickness
  S.beginPath();
  tick(0.14 / C.rimDensity * Math.PI / 180, (ca, sa, n) => {
    const m = ((n % 6) + 6) % 6;
    const li = m === 0 ? RB : RB * (0.5 + 0.35 * hash(n));
    const lo = m === 0 ? RB : RB * (0.5 + 0.35 * hash(n + 77));
    S.moveTo(ca * (R + 1.5), sa * (R + 1.5)); S.lineTo(ca * (R + 1.5 + li), sa * (R + 1.5 + li));
    S.moveTo(ca * (RO - 1.5), sa * (RO - 1.5)); S.lineTo(ca * (RO - 1.5 - lo), sa * (RO - 1.5 - lo));
  });
  S.globalCompositeOperation = 'lighter';
  S.strokeStyle = `rgba(232,235,242,${Math.min(1, 0.035 * C.rimBright * C.rimBright)})`; S.lineWidth = 1.2 + 2.4 * C.rimBright; S.stroke();   // glow grows with brightness
  S.strokeStyle = `rgba(232,235,242,${Math.min(1, 0.08 * C.rimBright)})`; S.lineWidth = 1.4; S.stroke();
  S.globalCompositeOperation = 'source-over'; S.strokeStyle = `rgba(240,242,248,${Math.min(1, 0.88 * C.rimBright)})`; S.lineWidth = 0.55; S.stroke();
  // rims
  const arc = (r, lw, a) => { S.strokeStyle = `rgba(232,235,242,${a})`; S.lineWidth = lw; S.beginPath(); S.arc(0, 0, r, -thV, thV); S.stroke(); };
  arc(R, 1.5, 1); arc(R + RB + 3, 0.6, 0.6); arc(RO - RB - 3, 0.6, 0.55);
  S.globalCompositeOperation = 'lighter'; arc(RO, 3.5, 0.1); S.globalCompositeOperation = 'source-over';
  arc(RO, 1.3, 0.95);
  S.beginPath();
  tick(1 * Math.PI / 180, (ca, sa) => { S.moveTo(ca * (R - 2), sa * (R - 2)); S.lineTo(ca * (R - 5), sa * (R - 5)); });
  tick(0.25 * Math.PI / 180, (ca, sa, n) => {
    const m = ((n % 20) + 20) % 20, L = m === 0 ? 9 : m % 5 === 0 ? 5 : 2.5;
    S.moveTo(ca * (RO + 2), sa * (RO + 2)); S.lineTo(ca * (RO + 2 + L), sa * (RO + 2 + L));
  });
  S.strokeStyle = 'rgba(230,233,240,.5)'; S.lineWidth = 0.6; S.stroke();
  S.restore();
}

/* ---------- frame ---------- */
function drawStage(dt) {
  updateBeat(dt); updateCam(dt); updateOuter(dt);
  if (rnd() < dt * C.cometTrickle) spawnComet();
  webRot += dt * (0.03 + env * 0.12) * C.webSpin;
  updateRing(dt);
  for (let k = 0; k < 3; k++) layerEnv[k] *= Math.exp(-dt * 2.2);

  // background
  S.setTransform(DPR, 0, 0, DPR, 0, 0);
  S.globalCompositeOperation = 'source-over'; S.globalAlpha = 1;
  S.fillStyle = '#08090b'; S.fillRect(0, 0, W, H);

  // glow buffer (low-res, blurred later)
  const G = glowC.x;
  let glowDrawn = false;
  G.setTransform(1, 0, 0, 1, 0, 0); G.clearRect(0, 0, glowC.width, glowC.height);
  camT(G, 1 / GS); G.globalCompositeOperation = 'lighter';

  camTk(S, DPR, 1 - 0.1 * C.parallax);   // the web sits a little further back

  // inner web + pulsing layers
  S.save(); S.translate(cx, cy); S.rotate(webRot);
  const ws = 2 * R + 4;
  S.drawImage(webBase, -R - 2, -R - 2, ws, ws);
  S.globalCompositeOperation = 'lighter';
  webLayers.forEach((c, k) => { S.globalAlpha = Math.min(1, C.webPulseBase + C.webPulseAmp * layerEnv[k]); S.drawImage(c, -R - 2, -R - 2, ws, ws); });
  S.globalAlpha = 1;

  // runners: speed surges on the beat
  const tx = trailC.x, surge = 0.5 + 2.5 * env;
  while (runners.length < C.runnerCount) runners.push(newRunner(true));
  if (runners.length > C.runnerCount) runners.length = Math.max(0, Math.round(C.runnerCount));
  tx.globalCompositeOperation = 'destination-out';
  tx.fillStyle = `rgba(0,0,0,${0.05 + env * 0.05})`; tx.fillRect(0, 0, ws, ws);
  tx.globalCompositeOperation = 'source-over';
  tx.save(); tx.translate(R + 2, R + 2); tx.lineCap = 'round';
  // Individual strokes retain upstream alpha overlap, draw order, and WebKit's
  // single-segment rasterization. The budget profile can batch the two paints.
  const runnerPaths = settings.originalCompositing ? null : [new Path2D(), new Path2D()];
  for (let i = 0; i < runners.length; i++) {
    const r = runners[i];
    r.t += dt * C.runnerSpeed * (r.mode === 1 ? r.sp * surge : r.mode === 2 ? r.sp + 1.3 * r.t * r.t : r.sp);
    if (r.t >= 1) { runners[i] = newRunner(false); continue; }
    const p = qpt(r.cv, r.t);
    if (runnerPaths) {
      const path = runnerPaths[r.b ? 1 : 0];
      path.moveTo(r.px, r.py); path.lineTo(p.x, p.y);
    } else {
      tx.strokeStyle = r.b ? `rgba(240,166,198,${Math.min(1, 0.9 * C.runnerBright)})` : `rgba(250,251,255,${Math.min(1, 0.75 * C.runnerBright)})`;
      tx.lineWidth = (r.b ? 1.3 : 0.9) * C.runnerWidth;
      tx.beginPath(); tx.moveTo(r.px, r.py); tx.lineTo(p.x, p.y); tx.stroke();
    }
    r.px = p.x; r.py = p.y;
  }
  if (runnerPaths) for (let tint = 0; tint < 2; tint++) {
    tx.strokeStyle = tint ? `rgba(240,166,198,${Math.min(1, 0.9 * C.runnerBright)})` : `rgba(250,251,255,${Math.min(1, 0.75 * C.runnerBright)})`;
    tx.lineWidth = (tint ? 1.3 : 0.9) * C.runnerWidth;
    tx.stroke(runnerPaths[tint]);
  }
  tx.restore();
  S.drawImage(trailC, -R - 2, -R - 2, ws, ws);
  S.restore();
  camT(S, DPR);
  // ring occlusion: the web darkens toward the ring, separating the two planes
  if (C.ringShadow > 0) {
    const sg = S.createRadialGradient(cx, cy, R - 110, cx, cy, R);
    sg.addColorStop(0, 'rgba(4,5,6,0)'); sg.addColorStop(1, `rgba(4,5,6,${Math.min(1, 0.8 * C.ringShadow)})`);
    S.globalCompositeOperation = 'source-over'; S.globalAlpha = 1; S.fillStyle = sg;
    S.beginPath(); S.arc(cx, cy, R, 0, TAU); S.arc(cx, cy, R - 110, 0, TAU, true); S.fill('evenodd');
  }

  // comets
  S.save(); S.translate(cx, cy); S.globalCompositeOperation = 'lighter'; S.lineCap = 'round';
  G.save(); G.translate(cx, cy);
  for (let i = comets.length - 1; i >= 0; i--) {
    const c = comets[i];
    c.life += dt;
    const p = easeIO(Math.min(1, c.life / c.dur));
    const head = Math.min(1, p * (1 + c.win)), tail = Math.max(0, p * (1 + c.win) - c.win);
    const fade = c.life > c.dur ? Math.max(0, 1 - (c.life - c.dur) / 0.25) : 1;
    if (fade <= 0) { comets.splice(i, 1); continue; }
    const cr = C.cometFollow ? ringRot - c.rot0 : 0;
    if (head >= 1 && !c.hit) { c.hit = true; const pe = cpt(c.lines[c.lines.length >> 1], 1); flashSlotAt(Math.atan2(pe.y, pe.x) + cr); }
    S.save(); S.rotate(cr); G.save(); G.rotate(cr);
    const col = c.tint ? '200,190,250' : '255,255,255';
    S.strokeStyle = `rgba(${col},${Math.min(1, 0.5 * fade * C.cometBright)})`; S.lineWidth = 1;
    strokeComet(S, c, tail, head);
    const hs = head - (head - tail) * 0.35;
    S.strokeStyle = `rgba(${col},${Math.min(1, fade * C.cometBright)})`; S.lineWidth = 1.7;
    strokeComet(S, c, hs, head);
    if (c.glow && C.cometGlow > 0) { G.strokeStyle = `rgba(${col},${Math.min(1, 0.5 * fade * C.cometGlow)})`; G.lineWidth = 2.8; strokeComet(G, c, hs, head); glowDrawn = true; }
    G.restore(); S.restore();
  }
  G.restore();
  S.restore();

  // outer wedges
  S.globalCompositeOperation = 'lighter';
  S.drawImage(laneC, 0, 0, W, H);
  // far outer layers 鈫?half-res buffer, composited blurred (depth of field)
  const F = farC.x;
  F.setTransform(1, 0, 0, 1, 0, 0); F.globalAlpha = 1; F.globalCompositeOperation = 'source-over'; F.clearRect(0, 0, farC.width, farC.height);
  camT(F, FS); F.globalCompositeOperation = 'lighter';
  S = F; drawOuterFar(); S = S_MAIN;
  S.save(); S.setTransform(DPR, 0, 0, DPR, 0, 0); S.globalCompositeOperation = 'lighter';
  if (HAS_FILTER && C.depthBlur > 0) S.filter = `blur(${C.depthBlur}px)`;
  S.globalAlpha = Math.min(1, C.depthDim); S.drawImage(farC, 0, 0, W, H);
  S.restore();
  // atmosphere: faint scattered light just beyond the ring
  if (C.atmos > 0) {
    const ag = S.createRadialGradient(cx, cy, RO, cx, cy, RO + (RMAX - RO) * 0.7);
    ag.addColorStop(0, `rgba(190,180,240,${Math.min(1, 0.07 * C.atmos)})`); ag.addColorStop(0.4, `rgba(150,145,210,${Math.min(1, 0.028 * C.atmos)})`); ag.addColorStop(1, 'rgba(0,0,0,0)');
    S.globalAlpha = 1; S.fillStyle = ag; S.beginPath(); S.arc(cx, cy, RMAX, 0, TAU); S.arc(cx, cy, RO, 0, TAU, true); S.fill('evenodd');
  }
  drawOuterNear();

  drawRing(dt);

  // composite soft glow
  S.setTransform(DPR, 0, 0, DPR, 0, 0);
  if (glowDrawn) {
    S.globalCompositeOperation = 'lighter';
    if (HAS_FILTER) S.filter = 'blur(6px)';
    S.globalAlpha = Math.min(1, 0.9 * C.glow);
    S.drawImage(glowC, 0, 0, glowC.width * GS, glowC.height * GS);
    if (HAS_FILTER) S.filter = 'none';
  }
  S.globalAlpha = 1; S.globalCompositeOperation = 'source-over';

  drawBokeh(dt);
  if (C.vignette > 0) {
    S.setTransform(DPR, 0, 0, DPR, 0, 0);
    const vg = S.createRadialGradient(W * 0.45, H * 0.5, Math.min(W, H) * 0.35, W * 0.45, H * 0.5, Math.hypot(W, H) * 0.62);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, `rgba(0,0,0,${Math.min(1, 0.75 * C.vignette)})`);
    S.fillStyle = vg; S.fillRect(0, 0, W, H);
  }

  drawCallout();
}

/* ---------- callout box with leader line (follows the camera) ---------- */
const CHECKS = [['STABILITY CHECK', 'CFL = |u| Δt / Δx'], ['MASS CONSERVATION', 'Σ ρ dV = const'], ['RESIDUAL NORM', 'r = ‖b − A·u‖₂'],
  ['BOUNDARY', 'u · n = 0  on ∂Ω'], ['PROJECTION', '∇²p = ∇ · u* / Δt']];
let chkI = 0;
const chkEl = document.getElementById('chk');
function drawCallout() {
  const a = -thS * 0.32;
  const anchor = toScreen(cx + Math.cos(a) * (RO + 30), cy + Math.sin(a) * (RO + 30));
  const box = toScreen(cx + Math.cos(a) * (RO + 30) + 120, cy + Math.sin(a) * (RO + 30) - 40);
  const bx = Math.min(W - 190, Math.max(8, box.x)), by = Math.min(H - 60, Math.max(40, box.y));
  chkEl.style.transform = `translate(${bx}px,${by}px)`;
  S.strokeStyle = 'rgba(230,233,238,.55)'; S.lineWidth = 0.8;
  S.beginPath(); S.moveTo(anchor.x, anchor.y); S.lineTo(bx, by + 12); S.stroke();
  S.fillStyle = '#fff'; S.fillRect(anchor.x - 1.5, anchor.y - 1.5, 3, 3);
}
runtime.every(() => {
  chkEl.style.opacity = 0;
  runtime.after(() => {
    chkI = (chkI + 1) % CHECKS.length;
    document.getElementById('chkK').textContent = CHECKS[chkI][0];
    document.getElementById('chkV').textContent = CHECKS[chkI][1];
    chkEl.style.opacity = 1;
  }, 400);
}, 3600);

/* =========================================================
   HEADER KPIs
   ========================================================= */
const segs = document.querySelectorAll('.kpi .seg i');
function kpiTick() {
  segs.forEach(s => s.style.width = rr(25, 100) + '%');
  const m = 5 + (rnd() * 6 | 0);
  document.getElementById('stBig').textContent = `${m} / 11 METHODS · ${11 - m} PENDING`;
}
kpiTick(); runtime.every(kpiTick, 2600);

/* =========================================================
   PANELS
   ========================================================= */
// --- method workspace (typing) ---
const CODE = [['papers', 'load_collection', '()'], ['eqs', 'extract_equations', '(papers)'], ['inputs', 'shared_scene', '()'],
  ['state', 'method.step', '(inputs)'], ['', 'check_mass', '(state, reference)'], ['', 'check_stability', '(state)'],
  ['', 'compare_reference', '(state)'], ['', 'attach_page_refs', '(eqs)'], ['', 'retain_missing_details', '()'],
  ['', 'package_clean_checkout', '()']];
const codeEl = document.getElementById('code');
let cLine = 0, cChar = 0, cNum = 7, typed = [];
const codeStr = l => (l[0] ? l[0] + ' = ' : '') + l[1] + l[2];
function codeHtml(l, n) {
  const pre = l[0] ? l[0] + ' = ' : '', full = pre + l[1] + l[2];
  n = n == null ? full.length : n;
  let out = '', i = 0;
  const seg = (s, cls) => { const take = Math.max(0, Math.min(s.length, n - i)); if (take) out += `<span class="${cls}">${s.slice(0, take)}</span>`; i += s.length; };
  seg(pre, 'op'); seg(l[1], 'fn'); seg(l[2], 'op');
  return out;
}
function codeTick() {
  const l = CODE[cLine];
  cChar += 2;
  if (cChar > codeStr(l).length + 6) {
    typed.push(`<div><span class="ln">${String(cNum++).padStart(3, '0')}</span>${codeHtml(l)}</div>`);
    if (typed.length > 12) typed.shift();
    cLine = (cLine + 1) % CODE.length; cChar = 0;
  }
  codeEl.innerHTML = typed.join('') + `<div><span class="ln">${String(cNum).padStart(3, '0')}</span>${codeHtml(CODE[cLine], cChar)}<span class="caret"></span></div>`;
}
runtime.every(codeTick, 70);

// --- routes ---
const ROUTES = ['navier-st', 'settings', 'lbm-d2q9', 'stam-fluid', 'page refs', 'missing'];
const COLSR = ['extract', 'attach', 'inspect'];
const routesEl = document.getElementById('routes');
const rState = ROUTES.map(() => (rnd() * 4) | 0);
function renderRoutes() {
  let h = '<span class="h">PAPER</span><span class="h">EXTRACT</span><span class="h">CODE</span><span class="h">CHECK</span>';
  ROUTES.forEach((n, i) => {
    h += `<span class="nm">${n}</span>`;
    COLSR.forEach((c, j) => {
      const st = rState[i];
      const cls = j < st ? 'done' : j === st ? (i === 5 ? 'pk' : 'on') : '';
      h += `<span><span class="chip ${cls}">${c}</span></span>`;
    });
  });
  routesEl.innerHTML = h;
}
runtime.every(() => { const i = (rnd() * ROUTES.length) | 0; rState[i] = (rState[i] + 1) % 4; renderRoutes(); }, 500);
renderRoutes();

// --- agents ---
const ROLES = ['read', 'build', 'review', 'qa'];
const AG = Array.from({ length: 12 }, (_, i) => ({ id: String(i + 1).padStart(2, '0'), role: ROLES[i % 4], p: rnd() * 8, sp: rr(0.6, 2), st: 'working' }));
const agEl = document.getElementById('agents');
const ROLE_COL = { read: '#98e0cf', build: '#f0a6c6', review: '#d7dae0', qa: '#f0a6c6' };
agEl.innerHTML = AG.map(a => `<div class="ag"><span class="id">${a.id}</span><span class="rl">${a.role}</span><span class="cells">${'<i></i>'.repeat(6)}</span><span class="st"></span></div>`).join('');
const agRows = [...agEl.children].map(row => ({
  cells: [...row.children[2].children], status: row.children[3], done: null, state: null,
}));
let agentPanelUpdates = 0;
function renderAgentRow(a, i) {
  const row = agRows[i], done = Math.floor(a.p);
  const state = a.p < 0.6 ? 'dispatch' : a.p > 6 ? 'idle' : 'working';
  let changed = false;
  if (row.done !== done) {
    row.cells.forEach((cell, k) => {
      cell.style.background = k < done ? ROLE_COL[a.role] : k === done ? '#5a5e66' : '#1d1f24';
    });
    row.done = done; changed = true;
  }
  if (row.state !== state) {
    row.status.textContent = state;
    row.status.className = 'st' + (state === 'working' ? ' w' : '');
    row.state = state; changed = true;
  }
  if (changed) agentPanelUpdates++;
}
AG.forEach(renderAgentRow);
function agentsTick(dt) {
  AG.forEach((a, i) => {
    a.p += a.sp * dt;
    if (a.p > 9) { a.p = 0; a.sp = rr(0.6, 2); }
    renderAgentRow(a, i);
  });
}

// --- canvases ---
const cAdv = document.getElementById('cAdv'), cDiff = document.getElementById('cDiff'), cVal = document.getElementById('cVal'), cIdx = document.getElementById('cIdx');
let advP = [];
function resizePanels() {
  [cAdv, cDiff, cVal, cIdx].forEach(fit);
  advP = Array.from({ length: 320 }, () => ({ x: rnd() * cAdv.w, y: rnd() * cAdv.h, l: rnd() * 3 }));
  valBuf = [[], [], []];
}
let T = 0;
const flow = (x, y) => Math.sin(x * 0.035 + T * 0.6) * Math.cos(y * 0.05 - T * 0.4) * Math.PI + Math.sin((x + y) * 0.01 + T * 0.2);
function drawAdv(dt) {
  const x = cAdv.x, w = cAdv.w, h = cAdv.h;
  x.fillStyle = 'rgba(14,15,18,0.22)'; x.fillRect(0, 0, w, h);
  x.fillStyle = 'rgba(120,125,135,.25)';
  for (let i = 6; i < w; i += 12) for (let j = 6; j < h; j += 12) x.fillRect(i, j, 1, 1);
  x.strokeStyle = 'rgba(235,238,244,.7)'; x.lineWidth = 0.8; x.beginPath();
  for (const p of advP) {
    const a = flow(p.x, p.y), nx = p.x + Math.cos(a) * 22 * dt, ny = p.y + Math.sin(a) * 22 * dt;
    x.moveTo(p.x, p.y); x.lineTo(nx + Math.cos(a) * 2, ny + Math.sin(a) * 2);
    p.x = nx; p.y = ny; p.l -= dt;
    if (p.l < 0 || p.x < 0 || p.x > w || p.y < 0 || p.y > h) { p.x = rnd() * w; p.y = rnd() * h; p.l = rr(1, 4); }
  }
  x.stroke();
}
runtime.every(() => { const b = document.querySelectorAll('#advBtns span'); const i = [...b].findIndex(s => s.classList.contains('on')); b[i].classList.remove('on'); b[(i + 1) % 3].classList.add('on'); }, 1400);

function drawDiff() {
  const x = cDiff.x, w = cDiff.w, h = cDiff.h;
  x.clearRect(0, 0, w, h);
  x.font = `600 7px ${FONT}`; x.textBaseline = 'top';
  const gap = 8, mw = (w - gap) / 2, mh = h * 0.68, cols = 22, rows = 13, cw = mw / cols, ch = (mh - 10) / rows;
  const hist = new Array(28).fill(0);
  for (let m = 0; m < 2; m++) {
    const ox = m * (mw + gap);
    x.fillStyle = '#6b6f78'; x.fillText(m ? 'IMPLEMENTATION' : 'REFERENCE', ox, 0);
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
      let v = 0.5 + 0.25 * Math.sin(i * 0.45 + T * 0.8) * Math.cos(j * 0.5 - T * 0.5) + 0.2 * Math.sin((i + j) * 0.3 + T);
      let err = 0;
      if (m) { const dx = i - 15 - Math.sin(T * 0.7) * 3, dy = j - 6; err = Math.exp(-(dx * dx + dy * dy) / 6) * (0.5 + 0.5 * Math.sin(T * 2)); v += err * 0.3; hist[Math.min(27, (err * 27) | 0)]++; }
      const g = Math.max(0, Math.min(255, v * 210 + 20)) | 0;
      x.fillStyle = err > 0.35 ? `rgba(240,166,198,${0.5 + err * 0.5})` : `rgb(${g},${g},${g + 4})`;
      x.fillRect(ox + i * cw, 10 + j * ch, cw - 0.6, ch - 0.6);
    }
  }
  const by = mh + 4, bh = h - by, bw = w / hist.length;
  const mx = Math.max(...hist.slice(1), 1);
  hist.forEach((v, i) => {
    const hh = i === 0 ? bh * 0.9 : (v / mx) * bh * 0.8 + 1;
    x.fillStyle = i > 9 ? '#f0a6c6' : '#8a8e97';
    x.fillRect(i * bw, by + bh - hh, bw - 1, hh);
  });
}

let valBuf = [[], [], []], valSpike = 0;
function drawVal() {
  const x = cVal.x, w = cVal.w, h = cVal.h;
  x.clearRect(0, 0, w, h);
  const lw = 58, n = Math.max(1, Math.floor((w - lw) / 2)), names = ['MASS', 'STABILITY', 'RESIDUAL'];
  if (rnd() < 0.01) valSpike = 1;
  valSpike *= 0.9;
  const vals = [Math.sin(T * 3) * 0.35 + Math.sin(T * 7.3) * 0.15 + gauss() * 0.06,
    Math.sin(T * 5 + 1) * 0.3 + Math.sin(T * 1.3) * 0.25 + gauss() * 0.08,
    Math.sin(T * 2.2) * 0.2 + gauss() * 0.15 + (rnd() < 0.5 ? 1 : -1) * valSpike * 0.9];
  vals.forEach((v, k) => { valBuf[k].push(v); while (valBuf[k].length > n) valBuf[k].shift(); });
  x.font = `800 7px ${FONT}`; x.textBaseline = 'middle';
  const rh = h / 3;
  for (let k = 0; k < 3; k++) {
    const yc = rh * k + rh / 2;
    x.fillStyle = '#9a9ea7'; x.fillText(names[k], 0, yc);
    x.strokeStyle = '#1f2227'; x.lineWidth = 1; x.beginPath(); x.moveTo(lw, yc); x.lineTo(w, yc); x.stroke();
    x.strokeStyle = k === 1 && valSpike > 0.2 ? '#f0a6c6' : '#e6e8ec'; x.lineWidth = 1.1;
    x.beginPath();
    valBuf[k].forEach((v, i) => { const px = lw + i * 2, py = yc - v * rh * 0.45; i ? x.lineTo(px, py) : x.moveTo(px, py); });
    x.stroke();
  }
  const cxr = lw + valBuf[0].length * 2;
  x.strokeStyle = 'rgba(240,166,198,.6)'; x.beginPath(); x.moveTo(cxr, 0); x.lineTo(cxr, h); x.stroke();
}

const IDX = Array.from({ length: 11 }, () => Array.from({ length: 28 }, () => rnd()));
function drawIdx() {
  const x = cIdx.x, w = cIdx.w, h = cIdx.h;
  x.clearRect(0, 0, w, h);
  x.font = `600 6.5px ${FONT}`; x.textBaseline = 'middle';
  const lx = 24, rx = 34, rows = 11, cols = 28, cw = (w - lx - rx) / cols, ch = h / rows;
  const scan = Math.floor((T * 6) % cols);
  if (rnd() < 0.3) { const r = (rnd() * rows) | 0, c = (rnd() * cols) | 0; IDX[r][c] = rnd(); }
  for (let j = 0; j < rows; j++) {
    x.fillStyle = '#6b6f78'; x.fillText('M' + String(j + 1).padStart(2, '0'), 0, j * ch + ch / 2);
    let match = 0;
    for (let i = 0; i < cols; i++) {
      const v = IDX[j][i];
      x.fillStyle = v > 0.86 ? '#f0a6c6' : v > 0.7 ? 'rgba(240,166,198,.45)' : v > 0.4 ? '#4a4e56' : '#1c1e23';
      if (i === scan) x.fillStyle = v > 0.4 ? '#ffffff' : '#3a3e46';
      x.fillRect(lx + i * cw, j * ch + 1, cw - 1, ch - 2);
      if (v > 0.7) match++;
    }
    x.fillStyle = match > 7 ? '#f0a6c6' : '#9a9ea7';
    x.fillText(match > 7 ? 'review' : 'match', w - rx + 4, j * ch + ch / 2);
  }
}


// A native screen saver uses ScreenSaverView's clock. A normal browser uses rAF.
// The native bridge permits only one JavaScript draw at a time.
const nativeDriver = !!window.HALOVEIL_NATIVE_FRAME_DRIVER;
let ready = false, raf = 0, last = 0, nextFrameAt = 0, frames = 0, resizeTask;
let lastPanels = 0, lastStats = 0, statsFrames = 0, measuredFPS = 0;
let nextPanelAt = 0, panelCursor = 0;
const panelLast = new Float64Array(4), panelUpdates = new Uint32Array(4);
let stageMS = 0, panelMS = 0, callbacks = 0, maxFrameMS = 0;
const frameCosts = new Float32Array(240), frameGaps = new Float32Array(240);
let sampleCount = 0, overBudgetFrames = 0;
let layoutBuilds = 0, resizeSkips = 0, lastLayoutAt = 0;
let fontsSettled = !document.fonts, warmupDrawing = false, warmupFrames = 0;
let warmupStarted = 0, warmupMS = 0, prepared = !window.HALOVEIL_NATIVE;
function percentile(buffer, fraction) {
  const values = Array.from(buffer.subarray(0, Math.min(sampleCount, buffer.length))).sort((a,b) => a-b);
  return values.length ? values[Math.min(values.length-1, Math.ceil(values.length*fraction)-1)] : 0;
}
const frameInterval = settings.fps > 0 ? 1000 / settings.fps : 0;
const frameBudget = frameInterval || 1000 / 60;
const panelInterval = settings.panelFPS > 0 ? 1000 / settings.panelFPS : 0;
function renderFrame(now) {
  callbacks++;
  if (!runtime.active || !ready) return;
  if (!nativeDriver && frameInterval && now + 1 < nextFrameAt) return;
  const gap = Math.max(0, now - last);
  const dt = Math.min(0.05, gap / 1000);
  last = now; T += dt;
  if (frameInterval) {
    nextFrameAt += frameInterval;
    if (nextFrameAt < now - 1) nextFrameAt = now + frameInterval;
  }
  const t0 = performance.now();
  drawStage(dt);
  const t1 = performance.now();
  stageMS = stageMS ? stageMS * 0.95 + (t1 - t0) * 0.05 : t1 - t0;
  if (!panelInterval) {
    drawAdv(dt); drawDiff(); drawVal(); drawIdx();
    for (let index = 0; index < 4; index++) panelUpdates[index]++;
    const cost = performance.now() - t1;
    panelMS = panelMS ? panelMS * 0.95 + cost * 0.05 : cost;
  } else if (now + 1 >= nextPanelAt) {
    // Spread four panel redraws across successive frames instead of stacking
    // their cost on one frame every 50 ms. Drop backlog rather than catch up.
    const step = panelInterval / 4;
    let updates = 0;
    do {
      const index = panelCursor++ % 4;
      const panelDT = Math.min(0.15, Math.max(0, (now-panelLast[index])/1000));
      panelLast[index] = now; panelUpdates[index]++;
      if (index === 0) drawAdv(panelDT);
      else if (index === 1) drawDiff();
      else if (index === 2) { drawVal(); }
      else drawIdx();
      nextPanelAt += step; updates++;
    } while (now + 1 >= nextPanelAt && updates < 2 && performance.now()-t0 < frameBudget*0.65);
    if (nextPanelAt < now-step) nextPanelAt = now+step;
    const cost = performance.now() - t1;
    panelMS = panelMS ? panelMS * 0.95 + cost * 0.05 : cost;
  }
  agentsTick(dt);
  const cost = performance.now() - t0;
  maxFrameMS = Math.max(maxFrameMS, cost);
  frameCosts[sampleCount % frameCosts.length] = cost;
  frameGaps[sampleCount % frameGaps.length] = gap;
  sampleCount++; if (cost > frameBudget) overBudgetFrames++;
  frames++; statsFrames++;
  if (now - lastStats >= 2000) {
    measuredFPS = statsFrames * 1000 / (now - lastStats);
    statsFrames = 0; lastStats = now;
  }
}
function frame(now) {
  raf = 0;
  renderFrame(now);
  if (runtime.active && ready && !nativeDriver) raf = requestAnimationFrame(frame);
}
function resetClock() {
  last = lastPanels = lastStats = performance.now();
  nextPanelAt = last; panelLast.fill(last);
  nextFrameAt = last + frameInterval;
  statsFrames = 0;
}
function startLoop() {
  if (!runtime.active || !ready) return;
  resetClock();
  if (!nativeDriver && !raf) raf = requestAnimationFrame(frame);
}
function resizeAll() {
  resizeTask = 0;
  if (runtime.disposed) return;
  const r = stage.getBoundingClientRect();
  if (r.width < 20 || r.height < 20) { ready = false; return; }
  const ratio = Math.min(window.devicePixelRatio || 1, settings.maxPixelRatio,
    Math.sqrt((settings.maxStagePixels || Infinity) / (r.width * r.height)));
  // ResizeObserver fires once on observation and again after page/font layout.
  // Rebuilding the unchanged atlas after playback began caused a startup freeze.
  if (ready && Math.abs(W-r.width) < 0.5 && Math.abs(H-r.height) < 0.5 && Math.abs(DPR-ratio) < 0.001) {
    resizeSkips++; return;
  }
  DPR = ratio; ready = false; prepared = !window.HALOVEIL_NATIVE;
  warmupFrames = 0; warmupStarted = 0;
  resizeStage(); resizePanels(); ready = true;
  layoutBuilds++; lastLayoutAt = performance.now();
  startLoop();
}
function prepareFrame() {
  if (runtime.disposed || !ready || !fontsSettled) return {prepared:false};
  if (!prepared) {
    if (!warmupStarted) {
      warmupStarted = performance.now();
      // Exercise the comet and glow paths before their first visible beat.
      for (let i=0;i<4;i++) {
        spawnComet(); const comet=comets[comets.length-1];
        comet.life=comet.dur*0.5; comet.glow=true; comet.tint=!!(i%2);
      }
      for (let i=0;i<8;i++) spawnFlyBurst();
    }
    if (warmupFrames === 36) { comets.length = 0; flyers = flyers.filter(flyer => !flyer.burst); }
    // Visit the complete ring before revealing it, so new tiles do not need
    // their first GPU upload during the opening rotation. Do not advance time.
    const savedRotation = ringRot;
    warmupDrawing = true;
    try {
      ringRot = warmupFrames * TAU / 12;
      // Zero-length paths are optimized away by the rasterizer. Warm real
      // short trail segments while keeping the visible simulation at time zero.
      if (warmupFrames < 36) for (const runner of runners) {
        const previous=qpt(runner.cv, Math.max(0,runner.t-0.001));
        runner.px=previous.x;runner.py=previous.y;
      }
      drawStage(0); drawAdv(0); drawDiff(); drawVal(); drawIdx();
    } finally { ringRot = savedRotation; warmupDrawing = false; }
    warmupFrames++;
    warmupMS = performance.now() - warmupStarted;
    // The final warm frame uses the actual opening orientation.
    if (warmupFrames >= 37 && performance.now()-lastLayoutAt >= 120) prepared = true;
  }
  return {prepared, layoutBuilds, warmupFrames, warmupMS};
}
runtime.onChange(active => {
  if (!active && raf) { cancelAnimationFrame(raf); raf = 0; }
  if (active) startLoop();
});
const resizeObserver = new ResizeObserver(() => {
  if (runtime.disposed) return;
  window.clearTimeout(resizeTask);
  // Preparation must complete while animation timers are still paused.
  resizeTask = window.setTimeout(resizeAll, 80);
});
resizeObserver.observe(document.getElementById('stageWrap'));
(document.fonts ? document.fonts.ready : Promise.resolve()).then(() => {
  fontsSettled = true; resizeAll();
});
window.HALOVEILHost = Object.freeze({
  setActive(active) { runtime.setActive(!!active); },
  prepareFrame,
  dispose() { resizeObserver.disconnect(); window.clearTimeout(resizeTask); runtime.dispose(); ready = false; },
  tick() { if (nativeDriver) renderFrame(performance.now()); },
  getState() {
    return {webRevision:release.version, build:release.build, ready, active:runtime.active, frames, time:T, fps:nativeDriver ? 60 : settings.fps || 'display',
      preset:settings.preset, config:{...C},
      qualityProfile:settings.qualityProfile, drawCostReferenceMS:frameBudget,
      agentPanel:{rows:AG.length, updates:agentPanelUpdates},
      motion:{tempo:C.tempo, ringSpeed:C.ringSpeed, ringPause:C.ringPause, cameraIntensity:C.camZoom},
      drawP95MS:percentile(frameCosts,0.95), gapP95MS:percentile(frameGaps,0.95), overBudgetFrames,
      slotBuildCount, slotBuildMS, layoutBuilds, resizeSkips, prepared, warmupFrames, warmupMS, panelUpdates:Array.from(panelUpdates), cameraShot:shotI, cameraPhase:camPhase,
      driver:nativeDriver ? 'ScreenSaverView' : 'requestAnimationFrame',
      measuredFPS, stageMS, panelMS, maxFrameMS, callbacks,
      pixelRatio:DPR, stagePixels:stage.width * stage.height,
      timers:runtime.timerCount, pendingTimers:runtime.pendingCount,
      width:W || 0, height:H || 0, hidden:document.hidden, hasCanvasFilter:HAS_FILTER,
      errors:runtime.errors.slice(), audioElements:document.querySelectorAll('audio,video').length};
  }
});
